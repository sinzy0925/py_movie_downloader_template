import z01_template
import z02_template

z01_template.main()
z02_template.main()